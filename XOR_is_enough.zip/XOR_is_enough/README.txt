README
------

The following files are included in this zip: 


Wireworld_XOR.mc - pattern file containing Wireworld XOR gates: Single Input, Sync Inputs, Async Inputs

Wireworld_AND_NOT.mc - pattern file containing Wireworld AND_NOT gate: A & B, B only, A only 


WireWorld1.rule - rule file for Wireworld-1

Wireworld1_XOR.mc - pattern file containing Wireworld-1 XOR gates: Single Input, Sync Inputs, Async Inputs

Wireworld1_AND_NOT.mc - pattern file containing Wireworld-1 AND_NOT gate: A & B, B only, A only



To use these files in Golly, copy the .rule file into the Rules folder, and copy the .mc files into your Patterns folder.
